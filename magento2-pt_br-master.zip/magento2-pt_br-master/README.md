# Language Pack do Magento2 em Português do Brasil (pt_BR)
Tradução do Magento2 para português do Brasil. Este language pack é construído com as traduções feitas no repositório oficial de traduções do Magento 2: https://crowdin.com/project/magento-2/pt-BR.
Caso deseje colaborar com algum termo, favor fazê-lo no crowdin: https://crowdin.com/project/magento-2/pt-BR. As traduções serão constantemente atualizadas.

# Instalação
Composer
- Execute o comando `composer require flowecommerce/pt_br`

Manual:
- Crie o diretório app/i18n/flowecommerce/pt_br
- Efetue o download do repositório (git clone https://github.com/flowecommerce/magento2-pt_br ou faça o download do zip)
- Mova o conteúdo do repositório para a pasta e habilite a tradução
